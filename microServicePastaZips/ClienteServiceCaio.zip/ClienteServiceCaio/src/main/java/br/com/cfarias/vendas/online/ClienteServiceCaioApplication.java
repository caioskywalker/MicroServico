package br.com.cfarias.vendas.online;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClienteServiceCaioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClienteServiceCaioApplication.class, args);
	}

}

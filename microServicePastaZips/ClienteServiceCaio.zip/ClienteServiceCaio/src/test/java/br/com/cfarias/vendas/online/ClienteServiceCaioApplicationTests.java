package br.com.cfarias.vendas.online;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClienteServiceCaioApplicationTests {

	@Test
	void contextLoads() {
	}

}

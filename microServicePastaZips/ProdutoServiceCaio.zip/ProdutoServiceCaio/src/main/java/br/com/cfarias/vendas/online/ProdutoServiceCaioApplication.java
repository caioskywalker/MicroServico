package br.com.cfarias.vendas.online;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdutoServiceCaioApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdutoServiceCaioApplication.class, args);
	}

}
